### Flask Chatbot
This chatbot application combines a simple Flask backend with a JavaScript-enhanced frontend to offer both text and speech-based interaction capabilities.

### Adaptation
The user interface code is adapted from [binary-hood/ChatBot](https://github.com/binary-hood/ChatBot/tree/main) with added speech-to-text functionality.

### Prerequisites
- Python version 3.10.10
- ffmpeg for audio conversion to .wav (required by SpeechRecognizer)

### ffmpeg Installation
Windows:
1. Download ffmpeg from FFmpeg's official website. Choose the appropriate version for your system.
2. Extract the downloaded ZIP file. Inside, you'll find the bin directory containing ffmpeg.exe, ffplay.exe, and ffprobe.exe.
3. Add the path to the bin directory to your system's PATH environment variable:
- Search for "Edit the system environment variables" and open it.
- Click on "Environment Variables".
- Under "System variables", find and select the "Path" variable, then click "Edit".
- Click "New" and add the path to the bin directory.
- Click "OK" on all open dialogues to apply the changes.

### Setup Instructions
1. Ensure you have Python 3.10.10 installed on your system.
2. Create a virtual environment named flask:
 - `python -m venv flask`
3. Activate the virtual environment:
- Windows: `flask\Scripts\activate`
- Linux/macOS: `source flask/bin/activate`
4. Install required Python packages from requirements.txt:
- `pip install -r requirements.txt`

### LLM
This chatbot utilizes the Gemini-Pro model for speech recognition. You will need a free API key to use the model:
- Obtain a free API key [here](https://ai.google.dev/tutorials/setup).

### Running the Chatbot
After setting up the environment and installing all the necessary dependencies, you can start the Flask chatbot by executing the main script using `python app.py`. Make sure your virtual environment is activated whenever you run the chatbot.
