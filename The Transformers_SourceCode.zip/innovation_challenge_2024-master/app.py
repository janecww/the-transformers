from flask import Flask, render_template, request, jsonify
import os
import tempfile
from openai import OpenAI
import google.generativeai as genai
from dotenv import load_dotenv
import requests
import json
import copy
import polyline
import pandas as pd
from datetime import datetime
import speech_recognition as sr
from pydub import AudioSegment
import folium
from folium import plugins
from folium.features import CustomIcon
from datetime import time
from haversine import haversine


######## LIBRARIES
######## LIBRARIES

from transformers.models.oneformer.modeling_oneformer import OneFormerModelOutput
import requests
from PIL import Image
import requests
from io import BytesIO
import torch
from transformers import BlipProcessor, BlipForConditionalGeneration
from langchain.llms.openai import OpenAI
import json
from langchain.document_loaders import ImageCaptionLoader
from langchain_openai import OpenAI
from langchain import PromptTemplate, LLMChain
from langchain.memory import ConversationBufferMemory
from langchain.agents import Tool
from langchain_openai import ChatOpenAI
import googlemaps
import copy
import polyline
from langchain.chains import create_tagging_chain, create_tagging_chain_pydantic
from langchain.agents import tool
from langchain.agents import AgentType
from langchain.utilities import GoogleSerperAPIWrapper
from langchain.utilities import OpenWeatherMapAPIWrapper
from langchain.agents import initialize_agent
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.document_loaders import DataFrameLoader
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain import hub
from langchain.tools import BaseTool
from langchain_experimental.agents import create_pandas_dataframe_agent
from langchain.tools.retriever import create_retriever_tool
import os
import numpy as np
import pandas as pd
import requests
from dotenv import load_dotenv

import re
import matplotlib.pyplot as plt


load_dotenv()  # Load environment variables
secrets = {
    "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY"),
    "GOOGLE_API_KEY": os.getenv("GOOGLE_API_KEY"),
    "GOOGLE_MAP_API": os.getenv("GOOGLE_MAP_API_3"),
    'data_mall_api_key': os.getenv("DATA_MALL_API")
}
API_KEY = 'AIzaSyBR6TLurAJwYX_0RVGcWTnFvr0Vux4w1lA'
map_client = googlemaps.Client(key=API_KEY)


app = Flask(__name__)
@app.route("/")
def index():
    return render_template('chat.html')

@app.route("/get", methods=["GET", "POST"]) #should include memory
#To handle the incoming chat messages from the user
def chat():
    msg = request.form["msg"]
    input = msg
    return get_Chat_response(input)

#Generate the chatbot's response based on the user input by calling an agent
image_present = []
plot_present = []
def get_Chat_response(user_input):
    response = agent(user_input)
    if len(image_present) != 0:
        print(image_present)
        image_present.clear()
        print(image_present)
        return {
            "text": "Here is your map:",
            "imageUrl": "static\map_image.png"
            }
    elif  len(plot_present)!=0:
        plot_present.clear()
        return{
            "text": "Here is your plot:",
            "plotUrl": "static\temp_plot.png"
        }
    else:   
        return {'text': response['output']}

def convert_webm_to_wav(webm_path, wav_path):
    audio = AudioSegment.from_file(webm_path, format="webm")
    audio.export(wav_path, format="wav")

@app.route("/speech", methods=["POST"])
def speech_recog():
    if "audio_data" not in request.files:
        return jsonify({"error": "Audio data not found"}), 400

    audio_file = request.files["audio_data"]
    try:
        # Create a temporary file for the webm audio
        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as tmp_webm_file:
            audio_file.save(tmp_webm_file.name)
            print(f"Temporary .webm file created: {tmp_webm_file.name}, size: {os.path.getsize(tmp_webm_file.name)} bytes")
        
        # Convert .webm to .wav
        wav_file_path = f"{tmp_webm_file.name.replace('.webm','')}.wav"
        print(wav_file_path)
        convert_webm_to_wav(tmp_webm_file.name, wav_file_path)

        recognizer = sr.Recognizer()
        # Use the converted .wav file for recognition
        with sr.AudioFile(wav_file_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
            print("Transcription:", text)

            return jsonify({"recognized_text": text})

    except sr.UnknownValueError:
        # Specific advice for when the audio cannot be understood
        print('No audio captured')
        return jsonify({"error": "Could not understand audio. Please speak louder or more clearly and try again."}), 400

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"error": str(e)}), 500

    finally:
        # Clean up the temp files safely
        if os.path.exists(tmp_webm_file.name):
            os.remove(tmp_webm_file.name)
        if os.path.exists(wav_file_path):
            os.remove(wav_file_path)
            
#########################
### Helper Functions ###
########################
# Fetch and load data
def fetch_and_load_data(input):
    print("Fetching data from API...")
    # Set the API endpoint from the screenshot instructions.
    api_endpoint = "http://datamall2.mytransport.sg/ltaodataservice/"+input

    # Replace 'your_account_key_here' with the actual account key.
    account_key = "XUspJ+9CRt6aduCrXE2K5w=="

    # Set the headers as suggested in the documentation.
    headers = {
        'AccountKey': account_key,
        'accept': 'application/json'
    }

    # Set the required parameters
    params = {
    }
    response = requests.get(api_endpoint, headers=headers, params=params)

    if response.status_code == 200:
        print("Fetched data from API successfully.")
        data = response.json()
        # print(data)

        # Check if the 'value' key exists in your data and is not empty
        if 'value' in data and data['value']:
            # Normalize and flatten the data inside the 'value' key
            values_df = pd.json_normalize(data['value'])
            values_df['odata.metadata'] = data['odata.metadata']

    return values_df


# Get Geocode of location
def get_geocode(destination):
    geocode_result = map_client.geocode(destination)
    if geocode_result:
        # Extract the latitude and longitude of the destination
        destination_coords = (
        geocode_result[0]['geometry']['location']['lat'],
        geocode_result[0]['geometry']['location']['lng'])
        print(destination_coords)
        #return destination_coords
    else:
        print('Failed to geocode destination address:', destination)
    return destination_coords


# Function to determine closeness of lat and long (Used for traffic_route_call/Traffic Incident)
def is_close(point, station, threshold=0.05):  # Threshold in degrees, approx 5km
    return abs(float(point['lat']) - float(station['latitude'])) <= threshold and \
           abs(float(point['lng']) - float(station['longitude'])) <= threshold

# Get the location according to geocoordinates
def get_location_from_geocode(latitude, longitude):
    reverse_geocode_result = map_client.reverse_geocode((latitude, longitude))
    if reverse_geocode_result:
        # Extract the formatted address of the location
        location = reverse_geocode_result[0]['formatted_address']
        #print(location)
        return location

# For ploting map
def fetch_traffic_data():
    api_endpoint = "http://datamall2.mytransport.sg/ltaodataservice/TrafficIncidents"
    account_key = "XUspJ+9CRt6aduCrXE2K5w=="  # Use your actual account key
    headers = {'AccountKey': account_key, 'accept': 'application/json'}
    response = requests.get(api_endpoint, headers=headers)
    if response.status_code == 200:
        return response.json()['value']

# Function to fetch 2-hour weather forecast data
def fetch_weather_forecast():
    today = datetime.today()
    params = {"date": today.strftime("%Y-%m-%d")}  # Format date as YYYY-MM-DD
    response = requests.get('https://api.data.gov.sg/v1/environment/2-hour-weather-forecast', params=params)
    if response.status_code == 200:
        return response.json()


@tool
def get_word_length(word: str) -> int:
    """Returns the length of a word."""
    return len(word)

@tool
def follow_up(question: str) -> str:
    """Returns a follow up question"""
    template = """
        As a route advisor within Singpore, your objective is to gather all necessary information including the origin, destination, and preferred transportation mode to find an efficient and sustainable route for humans.

        Ask follow-up questions for this inquiry: {question}

        If the user's inquiry is unclear and if you're having trouble understanding it,, ask "Could you provide a bit more detail or clarify your question, please?"

        If you don't know where the user wants to go, ask "Where would you like to go?"

        If you don't know where the user is currently, ask "Where are you currently located or where would you like to start from?"

        If you don't know how they want to get there, ask "What mode of transportation do you prefer?"

        AI:
        """
    prompt_template = ChatPromptTemplate.from_template(template=template, question=question)
    llm = OpenAI(temperature=0.1)
    llm_chain = LLMChain(prompt= prompt_template, llm= llm)
    follow_up_question = llm_chain(question)
    return follow_up_question

@tool
def get_weather_news(question: str) -> str:
    """Used when the user wants to know both the weather and current news. Give traveling/route suggestions according to the weather and traffic information you know"""
    weather = OpenWeatherMapAPIWrapper().run(question)
    news = GoogleSerperAPIWrapper(type = 'news').run(question)
    answer = weather + news
    return answer

@tool
def get_train_alerts(question: str) -> str:
    """ MUST return the health answer when the user wants to take the train or when the user ask if there are any train disruptions"""
    # Make the API request
    payload = {}
    headers = {
      'AccountKey': 'wYbkhBxrTfC0O3qMM2Bpfw==', # personal account key 
      'accept': 'application/json'
    }
    url = "http://datamall2.mytransport.sg/ltaodataservice/TrainServiceAlerts"

    response = requests.request("GET", url, headers=headers, data=payload)
    json_data = response.text
    # Parse the JSON string into a Python dictionary
    data = json.loads(json_data)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the JSON response
        data = response.json()
        
        # Extract relevant information from the response
        status = data["value"]["Status"]
        affected_segments = data["value"]["AffectedSegments"]
        messages = data["value"]["Message"]
        
        # Check the status to determine the health message
        if status == 1:
            health = "Good news! There are currently no disruptions."
        elif status == 2 and affected_segments and messages:
            affected_direction = affected_segments[0].get("Direction", "unknown")
            affected_line = affected_segments[0].get("Line", "unknown")
            message_content = messages[0].get("Content", "No message available")
            health_answer = f"There might be some delay along the {affected_line} line in the direction of {affected_direction}. This is the most updated message from LTA: {message_content}"
        else:
            health_answer = "No train service alerts found."

        print(health)
    else:
        None

    
    

@tool
def taxi_availability(location:str) -> int :
    """
    Return the number of available taxi when users ask if there are any available taxi nearby
    """
    destination_coords = get_geocode(location)
    
    # Extract the latitude and longitude of the destination
    latitude = destination_coords[0]
    longitude = destination_coords[1]

    result = requests.get('https://api.data.gov.sg/v1/transport/taxi-availability')
    taxi = json.loads(result.text)
    taxi_data = taxi['features'][0]['geometry']['coordinates']
    
    taxi_df = pd.DataFrame(taxi_data, columns = ['longitude', 'latitude'])

    user_coords = latitude, longitude

    available_taxis_count = 0
    # Iterate through taxi_df and calculate distances
    for index, row in taxi_df.iterrows():
        taxi_coords =  row['latitude'], row['longitude']
        distance = haversine(taxi_coords, user_coords)
        if distance <= 3:  # Considering 3 km radius
            available_taxis_count += 1

    taxi_answer = 'There are currently: '+ str(available_taxis_count) + " taxis within 3km."
    return taxi_answer

@tool
def get_carpark_availability(location:str)->str:
    """Return the names of the nearby carparks and the number of available lots in the nearby carparks when users ask what is the carpark availability of a location"""
    destination_coords = get_geocode(location)
    ### Check Carpark avaialbility
    # Fetch and process data >>> Calculate Distance between destination and car parks
    carparks_df = fetch_and_load_data("CarParkAvailabilityv2")
    carparks_df['Latitude'] = pd.to_numeric(carparks_df['Location'].apply(lambda y: y.split(' ')[0]))
    carparks_df['Longitude'] = pd.to_numeric(carparks_df['Location'].apply(lambda y: y.split(' ')[-1]))
    carparks_df['Distance'] =  np.sqrt((carparks_df['Latitude'] - destination_coords[0])**2 +
                            (carparks_df['Longitude'] - destination_coords[1])**2)
    # Create an agent to make computations
    carparks_agent = create_pandas_dataframe_agent(OpenAI(temperature=0), carparks_df, verbose=True)
    # Find the closest carpark(s)
    closest_carpark = carparks_agent.invoke("Which 3 Carparks have the smallest distance according to the 'Development' and the 'AvailableLots' columns ?")
    #closest_carpark_name =  carparks_agent.invoke('Identify the Development names of '+closest_carpark)
    # Find the number of lots available in the closest carpark(s)
    query = 'Given '+ closest_carpark['output'] + ', how many available lots do these CarParkID have in total?'
    closest_lots = carparks_agent.invoke(query)
    # Checkpoint
    carpark_answer = 'I find the closest car park for you: '+ closest_carpark['output'] +' and the total number of their available lots: '+ closest_lots['output']
    return carpark_answer
    
@tool
def review_driving_chain(query:str)->str:
    """USED when the user wants to drive from a starting point to a destination. Return the number of available carparks nearby and the traffic conditions for them. Alsp determine whether driving is an efficient, feasible and favorable option."""
    #### Step 1: Extract components
    schema = {
        "properties": {
            "start": {
                "type": "string",
                "description": "Identify where the user wants to start from (i.e., the origin or the starting location)"
            },
            "end": {
                "type": "string",
                "description": "Identify where the user wants to go (i.e., the destination or the ending location)"},
        },
        "required": ["start", "end"],
        }
    # Create a chain for components extraction
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613", openai_api_key=secrets['OPENAI_API_KEY'])
    chain = create_tagging_chain(schema, llm)
    # Trigger chain 
    review_output = chain.invoke(query)
    # Checkpoint
    print(review_output['text'])
    start = review_output['text']['start']
    end = review_output['text']['end']
    mode = 'driving'
    # Append review query
    review_query = 'The user wants to go from ' + str(start) + ' to ' + str(end) + ' by driving.\n\n'
    # Get geocode
    destination_coords = get_geocode(end)
    start_coords = get_geocode(start)
    print(str(start), str(end), str(mode), start_coords,destination_coords)

    ### Step 2: Check Carpark avaialbility
    # Fetch and process data >>> Calculate Distance between destination and car parks
    carparks_df = fetch_and_load_data("CarParkAvailabilityv2")
    carparks_df['Latitude'] = pd.to_numeric(carparks_df['Location'].apply(lambda y: y.split(' ')[0]))
    carparks_df['Longitude'] = pd.to_numeric(carparks_df['Location'].apply(lambda y: y.split(' ')[-1]))
    carparks_df['Distance'] =  np.sqrt((carparks_df['Latitude'] - destination_coords[0])**2 +
                            (carparks_df['Longitude'] - destination_coords[1])**2)
    # Create an agent to make computations
    carparks_agent = create_pandas_dataframe_agent(OpenAI(temperature=0), carparks_df, verbose=True)
    # Find the closest carpark(s)
    closest_carpark = carparks_agent.invoke("Which 3 Carparks have the smallest distance according to the 'Development' and the 'AvailableLots' columns ?")
    #closest_carpark_name =  carparks_agent.invoke('Identify the Development names of '+closest_carpark)
    # Find the number of lots available in the closest carpark(s)
    query = 'Given '+ closest_carpark['output'] + ', how many available lots do these CarParkID have in total?'
    closest_lots = carparks_agent.invoke(query)
    # Checkpoint
    review_query+= 'I find the closest car park for you: '+ closest_carpark['output'] +' and the total number of their available lots: '+ closest_lots['output']+'\n\n'
    print(closest_lots)
    print(review_query)
    
    ### Step 3: Check Traffic incidents
    # Get the route latitudes and longitudes
    directions_result = map_client.directions(start+' Singapore', end+' Singapore', mode=mode)
    route_data = directions_result[0]['legs'][0]
    # Concise copy to return to llm
    route_data_concise = copy.deepcopy(route_data)
    route_data_concise['steps'] = [r['html_instructions'] for r in route_data_concise['steps']]
    # Get the polyline        
    polyline_encoded = directions_result[0]['overview_polyline']['points']
    polyline_points = polyline.decode(polyline_encoded)

    # Fetch traffic incidents
    incidents_df = fetch_and_load_data("TrafficIncidents")
    incidents_df['Latitude'] = incidents_df['Latitude'].astype(float)
    incidents_df['Longitude'] = incidents_df['Longitude'].astype(float)
    # Find the relevant incidents 
    incident_along_route = []
    for pt in polyline_points:
        for index, incident_row in incidents_df.iterrows():
            incident_point = {'latitude': float(incident_row['Latitude']), 'longitude': float(incident_row['Longitude'])}
            if is_close({'lat': pt[0], 'lng': pt[1]}, incident_point, threshold=0.001):
                incident_along_route.append(incident_row)
    unique_incidents_along_route = {tuple(row) for row in incident_along_route}
    unique_incidents_along_route_df = pd.DataFrame(list(unique_incidents_along_route), columns=incidents_df.columns)
    print(unique_incidents_along_route)
    if (len(unique_incidents_along_route) == 0):
        incidents_result = "No traffic accidents/heavy traffic/roadworks"
        review_query += "No traffic incidents detected! Driving is feasible and efficient. \n"
    else:
        review_query += str(unique_incidents_along_route)
        print(review_query)


    # Recommend to take taxi if they do not want to take the public transport
    latitude = start_coords[0]
    longitude = start_coords[1]

    result = requests.get('https://api.data.gov.sg/v1/transport/taxi-availability')
    taxi = json.loads(result.text)
    taxi_data = taxi['features'][0]['geometry']['coordinates']
    
    taxi_df = pd.DataFrame(taxi_data, columns = ['longitude', 'latitude'])

    user_coords = latitude, longitude

    available_taxis_count = 0
    # Iterate through taxi_df and calculate distances
    for index, row in taxi_df.iterrows():
        taxi_coords =  row['latitude'], row['longitude']
        distance = haversine(taxi_coords, user_coords)
        if distance <= 3:  # Considering 3 km radius
            available_taxis_count += 1

    review_query += 'There are currently: '+ str(available_taxis_count) + " taxis within 3km. I would recommend to take a taxi if you are unable to take the bus or mrt as it is a more sustainable way of travelling compared to driving. \n"
    print(review_query)


    # Final Decision
    final_query = f"""Generate your response by evaluating what you have observed so far: {review_query}
     Given the number of available lots in the nearby carparks, the current traffic conditions (i.e., roadworks, heavy traffic, accidents) and the number of taxi available, do you think driving is a feasible, efficient, and favorable option for the user? 

     ***** SHARE EVERYTHING YOU HAVE AND BE HONEST! 
     Please answer this question logically based on the content of the review query and provide 2 reasons why you think this is an ideal option or not. 

     If you don't think driving is recommendable, suggest the user sustainable alternative, e.g. taking public transport

    Based on the observation, our thought process MUST include:
    1) the number of available car parks: {closest_lots} (YOU MUST MENTION THIS!!!!)
    2) Evaluate whether there are a lot of car parks. If the number of car parks is greater than 30, it is considered many lots available. And driving should be feasible if there are no traffic incidents.
    3) the name of the car park s(YOU MUST MENTION THIS!!!!)
    4) a summary fo traffic conditions (i.e., roadworks, heavy traffic, accidents)  (YOU MUST MENTION THIS!!!!)
    5) your answer to the user and rationale behind (VERY IMPORTANT!!!)
    6) the number of available taxi (YOU MUST MENTION THIS!!!)
   
    """
    return final_query

@tool
def describe_traffic_cameras(query:str)->str:
    """Used when the user wants to know the description of traffic cameras along the way from the starting point to the destination"""
    #### Step 1: Extract components
    schema = {
        "properties": {
            "start": {
                "type": "string",
                "description": "Identify where the user wants to start from (i.e., the origin or the starting location)"
            },
            "end": {
                "type": "string",
                "description": "Identify where the user wants to go (i.e., the destination or the ending location)"},
        },
        "required": ["start", "end"],
        }
    # Create a chain for components extraction
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613", openai_api_key=secrets['OPENAI_API_KEY'])
    chain = create_tagging_chain(schema, llm)
    # Trigger chain 
    review_output = chain.invoke(query)
    # Checkpoint
    print(review_output['text'])
    start = review_output['text']['start']
    end = review_output['text']['end']
    
    #### Step 2: Fetch traffic images + Filter the traffic images within the route
    image = fetch_and_load_data("Traffic-Imagesv2")
    directions_result = map_client.directions(start +' Singapore', end +' Singapore', mode='driving')
    route_data = directions_result[0]['legs'][0]
    # Concise copy to return to llm
    route_data_concise = copy.deepcopy(route_data)
    route_data_concise['steps'] = [r['html_instructions'] for r in route_data_concise['steps']]
    # Get the polyline        
    polyline_encoded = directions_result[0]['overview_polyline']['points']
    polyline_points = polyline.decode(polyline_encoded)

    #### Step 3: Convert geo-coordinates to locations
    image_along_route=pd.DataFrame(columns= ['CameraID', 'Latitude', 'Longitude', 'ImageLink', 'odata.metadata'])
    i = 0
    for pt in polyline_points:
        for index, image_row in image.iterrows():
            image_point = {'latitude': image_row['Latitude'], 'longitude': image_row['Longitude']}
            if (is_close({'lat': pt[0], 'lng': pt[1]}, image_point, threshold=0.001)) :
                image_along_route.loc[i, 'CameraID'] = image_row['CameraID']
                image_along_route.loc[i, 'Latitude'] = image_row['Latitude']
                image_along_route.loc[i, 'Longitude'] = image_row['Longitude']
                image_along_route.loc[i, 'ImageLink'] = image_row['ImageLink']
                image_along_route.loc[i, 'odata.metadata'] = image_row['odata.metadata']
                i+=1
    image_along_route = image_along_route.drop_duplicates().reset_index(drop=True)
    image_along_route['Location'] = image_along_route.apply(lambda row: get_location_from_geocode(row['Latitude'], row['Longitude']), axis=1)
    #image_along_route

    #### Step 4: Load the image captioning model to describe traffic images
    image_to_text_model = "Salesforce/blip-image-captioning-large"
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    processor = BlipProcessor.from_pretrained(image_to_text_model)
    model = BlipForConditionalGeneration.from_pretrained(image_to_text_model).to(device)

    description = []
    image_along_route['Description'] = 'NA'
    i= 0
    for image_url in image_along_route['ImageLink']:
        response = requests.get(image_url)
        if response.status_code == 200:
            image_url = BytesIO(response.content)
            image_object = Image.open(image_url)
            inputs = processor(image_object, return_tensors="pt").to(device)
            outputs = model.generate(**inputs)
            image_along_route.loc[i, 'Description'] = processor.decode(outputs[0], skip_special_tokens=True)
            i+=1

    #### Step 5: Extract the location and corresponding description
    location_description_dict = {}
    for record in image_along_route.to_dict(orient='records'):
        location = record['Location']
        description = record['Description']
        location_description_dict[location] = description

    print(location_description_dict)
    #str(location_description_dict)

    final_query = f"""According to the image captioning model, this is my observation: {str(location_description_dict)}. The format in the curly brackets is like: location:description, location:description, location:description,...

    #IN OUR ANSWER, YOU MUST INCLUDE:
    1. List out the locations and their corresponding description according to your observation, and
    2. Describe how crowded the road now is along the way from {start} to {end}, and
    3. Suggest how the driver can avoid the traffic congestion if you detect a high volume of vehicles on the roads

    """
    return str(final_query)

@tool
def traffic_map(query:str)->str:
    """To be used to generate a map image of route"""
        #### Step 1: Extract components
    schema = {
        "properties": {
            "start": {
                "type": "string",
                "description": "Identify where the user wants to start from (i.e., the origin or the starting location)"
            },
            "end": {
                "type": "string",
                "description": "Identify where the user wants to go (i.e., the destination or the ending location)"},
        },
        "required": ["start", "end", "mode"],
        }
    # Create a chain for components extraction
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613", openai_api_key=secrets['OPENAI_API_KEY'])
    chain = create_tagging_chain(schema, llm)
    # Trigger chain 
    review_output = chain.invoke(query)
    # Checkpoint
    print(review_output['text'])
    start = review_output['text']['start']
    end = review_output['text']['end']

    directions_result = map_client.directions(start+' Singapore', end+' Singapore', mode='driving')   
    polyline_encoded = directions_result[0]['overview_polyline']['points']
    points = polyline.decode(polyline_encoded)

    # Create a map centered on the first point
    map_folium = folium.Map(location=[points[0][0], points[0][1]], zoom_start=30)

    # Add the route polyline to the map
    folium.PolyLine(points, color="blue", weight=2.5, opacity=1).add_to(map_folium)

    # Adding traffic markers...
    icons = {
        'Obstacle': 'https://i.ibb.co/jWMYJtp/Accident.png',
        'Vehicle Breakdown': 'https://i.ibb.co/jZmYqDt/warning-triangle-emergency-stop-sign-in-case-of-breakdown-car-breakdown-on-the-road-vector.png',
        'Accident': 'https://i.ibb.co/Yj6xX2R/Traffic-Barrier.png',
        'Roadwork': 'https://i.ibb.co/MPqsZvK/Roadwork.png',
    }
    traffic_data = fetch_traffic_data()
    for incident in traffic_data:
        icon_url = icons.get(incident['Type'], icons['Obstacle'])
        icon = CustomIcon(icon_url, icon_size=(40, 40))
        folium.Marker(
            [incident['Latitude'], incident['Longitude']],
            popup=incident['Message'],
            icon=icon
        ).add_to(map_folium)
    
    # Fetch and display 2-hour weather forecast data
    wx_forecast = fetch_weather_forecast()
    if wx_forecast:
        plotDf = pd.DataFrame(wx_forecast['area_metadata']).merge(
            pd.DataFrame(wx_forecast['items'][-1]['forecasts']).reset_index(), how='inner', left_on='name', right_on='area'
        )
    for _, row in plotDf.iterrows():
        icon_url = None
        # Define custom icon URLs for different weather conditions
        if row['forecast'] == "Light Rain":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Moderate Rain":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Heavy Rain":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Passing Showers":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Light Showers":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Showers":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Heavy Showers":
            icon_url = "https://i.ibb.co/rb27TBW/Rain.png"
        elif row['forecast'] == "Thundery Showers":
            icon_url = "https://i.ibb.co/jy0b5mj/Thunder.png"
        elif row['forecast'] == "Heavy Thundery Showers":
            icon_url = "https://i.ibb.co/jy0b5mj/Thunder.png"
        elif row['forecast'] == "Heavy Thundery Showers with Gusty Winds":
            icon_url = "https://i.ibb.co/jy0b5mj/Thunder.png"
        else:
            pass
        # Then use the icon_url for each marker
        if icon_url!= None:
            icon = CustomIcon(icon_url, icon_size=(30, 30))  # Adjust icon size as needed
            folium.Marker(
                location=[row['label_location']['latitude'], row['label_location']['longitude']],
                popup=row['forecast'],
                icon=icon,
                tooltip=row['area']
            ).add_to(map_folium)

    # Render the map to HTML
    map_file_path = 'temp_map.html'
    map_folium.save('static\\'+map_file_path)
    image_present.append("static\temp_map.html")
    return {
        "text": "Here is your map:",
        "imageUrl": "static\temp_map.html"
        }            

@tool
def traffic_summary(query:str)->str:
    """To be used to generate a summary of traffic incident for road traffic manager"""
    incident_url = 'http://datamall2.mytransport.sg/ltaodataservice/TrafficIncidents'
    incident_reports = requests.get(incident_url, headers = {
        'AccountKey': "XUspJ+9CRt6aduCrXE2K5w==",
        'accept': 'application/json'
    }).json()['value']
    messages = [incident['Message'] for incident in incident_reports]
    return messages

@tool
def volume_summary(query:str)->str:
    """To be used to generate a summary of bus or train volume. To get insights on the bus and train passenger volume"""
    schema = {
    "properties": {
        "mode": {
            "type": "string",
            "description": "Identify whether is bus or train"
        }
    },
    "required": ["mode"],
    }
    # Create a chain for components extraction
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613", openai_api_key=secrets['OPENAI_API_KEY'])
    chain = create_tagging_chain(schema, llm)
    # Trigger chain 
    review_output = chain.invoke(query)
    # Checkpoint
    print(review_output)
    mode = review_output['text']['mode']
    print(mode)
    if mode == 'bus':
        url = "http://datamall2.mytransport.sg/ltaodataservice/PV/Bus"
    elif mode == 'train':
        url = "http://datamall2.mytransport.sg/ltaodataservice/PV/Train"
    headers = {
            'AccountKey': "Fvwi59lTTCuCxnNC0/wprw==",
            'accept': 'application/json'
        }
    response = requests.get(url, headers=headers).json()
    print(response.keys())
    link = response['value'][0]['Link']

    # Send a GET request to the URL
    response = requests.get(link)

    # Check if the request was successful
    if response.status_code == 200:
        # Open a file in binary write mode
        with open("transport.zip", "wb") as file:
            file.write(response.content)
        print("Download completed successfully!")
    else:
        print("Failed to download the file.")

    import zipfile

    # Path to your zip file
    zip_file_path = 'transport.zip'  # Update this to your zip file's path

    # Initialize a variable to hold the CSV file name
    csv_file_name = None

    # List the files in the zip archive and find the first CSV file
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        for file in zip_ref.namelist():
            if file.endswith('.csv'):
                csv_file_name = file
                break  # Assuming you only need the first CSV file

        if csv_file_name:
            # Extract the found CSV file
            zip_ref.extract(csv_file_name)

    # Check if a CSV file was found and extracted
    if csv_file_name:
        # Load the extracted CSV file into a pandas DataFrame
        df = pd.read_csv(csv_file_name)
        # Display the first few rows of the DataFrame
        print(df.head())
    else:
        print("No CSV file found in the ZIP archive.")

    df = df.dropna()
    # Convert 'YEAR_MONTH' to datetime
    df['YEAR_MONTH'] = pd.to_datetime(df['YEAR_MONTH'], format='%Y-%m')  # Adjust the format as necessary

    # Convert volumes to integers (they're already int64, but here's how you'd ensure it)
    df['TOTAL_TAP_IN_VOLUME'] = df['TOTAL_TAP_IN_VOLUME'].astype(int)
    df['TOTAL_TAP_OUT_VOLUME'] = df['TOTAL_TAP_OUT_VOLUME'].astype(int)

    # Convert 'TIME_PER_HOUR' to datetime
    df['TIME_PER_HOUR'] = df['TIME_PER_HOUR'].apply(lambda x: time(int(x)))

    # Convert all other columns to string
    for column in df.columns:
        if column not in ['YEAR_MONTH', 'TOTAL_TAP_IN_VOLUME', 'TOTAL_TAP_OUT_VOLUME']:
            df[column] = df[column].astype(str)

    from pandasai import SmartDataframe
    from pandasai.llm import GooglePalm
    GOOGLE_API_KEY='AIzaSyCDcj8s4bYl7CdDWBZcsBAfmgfLMCdwuNA'
    # OPENAI_API_KEY = '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'
    llm = GooglePalm(api_key=GOOGLE_API_KEY)
    from pandasai.llm.openai import OpenAI
    # llm = OpenAI(api_token=OPENAI_API_KEY)
    sdf = SmartDataframe(df, config={"llm": llm})
    return sdf.chat(query)

@tool
def get_weather(location: str) -> str:
    """ Give traveling/route suggestions according location """
    current_datetime = datetime.now()

    # Format the datetime as per your requirement
    formatted_datetime = current_datetime.strftime('%Y-%m-%dT%H:%M:%S')

    # Parameters for the GET request
    params = {'date_time': formatted_datetime}

    result =requests.get('https://api.data.gov.sg/v1//environment/2-hour-weather-forecast', params=params).json()

    # get the area, lat and long
    area = result['area_metadata']
    area_df = pd.json_normalize(area, sep='_')
    area_df = area_df.rename(columns={'label_location_latitude': 'lat', 'label_location_longitude': 'long'})

    # get the 2-hr weather forecast in the area
    weather = result['items'][-1]['forecasts']
    forecast_df =  pd.DataFrame(weather)
    forecast_df

    destination_coords = get_geocode(location)
    
    # Extract the latitude and longitude of the destination
    latitude = destination_coords[0]
    longitude = destination_coords[1]

    closest_area = None
    min_distance = float('inf')

    for index, row in area_df.iterrows():
        area_coords =  row['lat'], row['long']
        distance = haversine(destination_coords, area_coords)
        if distance < min_distance:
            min_distance = distance
            closest_area = row['name']
    forecast = forecast_df[forecast_df['area']==closest_area]
    answer = forecast['forecast']
    weather_answer = "The weather at the location is expected to be " + str(answer)
    return weather_answer

# df = pd.read_csv('transport_node_bus_202402.csv')
# df_PassengerVolumeByBusStops = df.dropna()

def transform_data(data):
    # Define regex patterns for matching DAY_TYPE and Category
    day_type_pattern = re.compile(r'weekday|weekend|holiday')
    category_pattern = re.compile(r'tap in|tap out|tap_in|tap_out')

    # Find matches in the input data
    day_type_match = day_type_pattern.search(data['DAY_TYPE'])
    category_match = category_pattern.search(data['Category'])

    # Initialize transformed data
    transformed_data = data

    # Transform DAY_TYPE
    if day_type_match:
        if day_type_match.group() == 'weekday':
            transformed_data['DAY_TYPE'] = 'WEEKDAY'
        else:
            transformed_data['DAY_TYPE'] = 'WEEKEND/HOLIDAY'

    # Transform Category
    if category_match:
        if category_match.group() == 'tap in':
            transformed_data['Category'] = 'TOTAL_TAP_IN_VOLUME'
        elif category_match.group() == 'tap_in':
            transformed_data['Category'] = 'TOTAL_TAP_IN_VOLUME'
        else:
            transformed_data['Category'] = 'TOTAL_TAP_OUT_VOLUME'

    return transformed_data

import zipfile
@tool
def bus_volume_plot(query:str)->str:
    """To be used to generate a line plot of bus volume at a particular bus stop"""
        #### Step 1: Extract components
    schema = {
        "properties": {
            "DAY_TYPE": {
                "type": "string",
                "description": "Identify if user wants plot on weekday or weekend/holiday"
            },
            "PT_CODE": {
                "type": "string",
                "description": "Identify a 6 digit number that represent bus stop code"},
            "Category": {
                "type":"string",
                "description":"Identify if it is tap_in/tap in volume or tap_out/ tap out volume. If it is tap in volume, output as TOTAL_TAP_IN_VOLUME. If it is tap out volume, output as TOTAL_TAP_OUT_VOLUME"
            }   
        },
        "required": ["DAY_TYPE", "PT_CODE", "Category"],
        }

    
    # Create a chain for components extraction
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613", openai_api_key=secrets['OPENAI_API_KEY'])
    chain = create_tagging_chain(schema, llm)
    # Trigger chain 
    review_output = chain.invoke(query)
    # Checkpoint
    print(review_output['text'])
    review_output = transform_data(review_output['text'])
    DAY_TYPE = review_output['DAY_TYPE']
    PT_CODE =  int(review_output['PT_CODE'])
    Category = review_output['Category']
    print(DAY_TYPE, PT_CODE, Category)
    
    url = "http://datamall2.mytransport.sg/ltaodataservice/PV/Bus"
    headers = {
                'AccountKey': '18Zqc8UxT6StHb8bkesOoA==',
                'accept': 'application/json'
            }
    response = requests.get(url, headers=headers).json()
    # print(response.keys())

    link = response['value'][0]['Link']
    response = requests.get(link)
    if response.status_code == 200:
        with open("Dataset/PassengerVolumeByBusStops.zip", "wb") as file:
                file.write(response.content)
        print("Download completed successfully!")
    else:
        print("Failed to download the file.")
    
    
    zip_file_path = 'Dataset/PassengerVolumeByBusStops.zip'  # Update this to your zip file's path
    csv_file_name = None
    
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        for file in zip_ref.namelist():
            if file.endswith('.csv'):
                csv_file_name = file
                break  
        if csv_file_name:
            zip_ref.extract(csv_file_name)
    
    if csv_file_name:
        df_PassengerVolumeByBusStops = pd.read_csv(csv_file_name)
        df_PassengerVolumeByBusStops
    else:
        print("No CSV file found in the ZIP archive.")

    df_PassengerVolumeByBusStops['DAY_TYPE'] = df_PassengerVolumeByBusStops['DAY_TYPE'].str.lower()

    print(df_PassengerVolumeByBusStops)
    df_filtered = df_PassengerVolumeByBusStops[(df_PassengerVolumeByBusStops['DAY_TYPE'] == DAY_TYPE) & (df_PassengerVolumeByBusStops['PT_TYPE'] == 'BUS') & (df_PassengerVolumeByBusStops['PT_CODE'] == PT_CODE)]
    print(df_filtered)
    df_grouped = df_filtered.groupby('TIME_PER_HOUR')[Category].sum().reset_index()
    df_grouped_sorted = df_grouped.sort_values('TIME_PER_HOUR')
    print(df_grouped_sorted)
    
    plt.figure(figsize=(10, 6))
    plt.plot(df_grouped_sorted['TIME_PER_HOUR'], df_grouped_sorted[Category], marker='o', linestyle='-', color='b')
    plt.title(f'{Category} Over Time for Bus Stop {PT_CODE} on {DAY_TYPE.capitalize()}')
    plt.xlabel('Time per Hour')
    plt.ylabel(f'{Category}')
    plt.grid(True)
    plt.xticks(np.arange(min(df_grouped_sorted['TIME_PER_HOUR']), max(df_grouped_sorted['TIME_PER_HOUR'])+1, 1.0))
    plt.tight_layout()
    plt.savefig('static\\temp_plot.png', dpi=300) 
    plot_present.append("static\temp_plot.png")
    return {
        "text": "Here is your plot:",
        "plotUrl": "static\temp_plot.png"
        }     


@tool
def train_volume_plot(query:str)->str:
    """To be used to generate a line plot of train(MRT) volume at a particular train(MRT) stations"""
        #### Step 1: Extract components
    schema = {
        "properties": {
            "DAY_TYPE": {
                "type": "string",
                "description": "Identify if user wants plot on weekday or weekend/holiday"
            },
            "mrt_station_english": {
                "type": "string",
                "description": "Identify the mrt station names and output in lower casing alphabets"},
            "Category": {
                "type":"string",
                "description":"Identify if it is tap in volume or tap out volume"
            }   
        },
        "required": ["DAY_TYPE", "mrt_station_english", "Category"],
        }

        
    # Create a chain for components extraction
    llm = ChatOpenAI(temperature=0, model="gpt-3.5-turbo-0613", openai_api_key=secrets['OPENAI_API_KEY'])
    chain = create_tagging_chain(schema, llm)
    # Trigger chain 
    review_output = chain.invoke(query)
    # Checkpoint
    print(review_output['text'])
    review_output = transform_data(review_output['text'])
    DAY_TYPE = review_output['DAY_TYPE']
    mrt_station_english = review_output['mrt_station_english']
    Category = review_output['Category']
    print(DAY_TYPE, mrt_station_english,Category)

    url = "http://datamall2.mytransport.sg/ltaodataservice/PV/Train"
    headers = {
                'AccountKey': '18Zqc8UxT6StHb8bkesOoA==',
                'accept': 'application/json'
            }
    response = requests.get(url, headers=headers).json()
    print(response.keys())

    link = response['value'][0]['Link']
    response = requests.get(link)
    if response.status_code == 200:
        with open("Dataset/PassengerVolumeByTrainStations.zip", "wb") as file:
                file.write(response.content)
        print("Download completed successfully!")
    else:
        print("Failed to download the file.")
    
    
    zip_file_path = 'Dataset/PassengerVolumeByTrainStations.zip'  # Update this to your zip file's path
    csv_file_name = None
    
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        for file in zip_ref.namelist():
            if file.endswith('.csv'):
                csv_file_name = file
                break  
        if csv_file_name:
            zip_ref.extract(csv_file_name)
    
    if csv_file_name:
        df_PassengerVolumeByTrainStations = pd.read_csv(csv_file_name)
        df_PassengerVolumeByTrainStations
    else:
        print("No CSV file found in the ZIP archive.")

    file = 'Dataset/TrainStationCodes.xls'
    df_trainstationcodes = pd.read_excel(file)
    # df_trainstationcodes
    df_PassengerVolumeByTrainStations = pd.read_csv('transport_node_train_202402.csv')
    # print(df_PassengerVolumeByTrainStations)
    df_PassengerVolumeByTrainStations = pd.merge(df_PassengerVolumeByTrainStations, df_trainstationcodes[['stn_code', 'mrt_station_english']], left_on='PT_CODE', right_on='stn_code', how='left')
    # print(df_PassengerVolumeByTrainStations)
    df_PassengerVolumeByTrainStations = df_PassengerVolumeByTrainStations.drop('stn_code', axis=1)

    df_PassengerVolumeByTrainStations = df_PassengerVolumeByTrainStations.dropna(subset=['mrt_station_english'])
    # df_PassengerVolumeByTrainStations['mrt_station_english'] = df_PassengerVolumeByTrainStations['mrt_station_english'].str.lower()
    # df_PassengerVolumeByTrainStations['DAY_TYPE'] = df_PassengerVolumeByTrainStations['DAY_TYPE'].str.lower()


    df_filtered = df_PassengerVolumeByTrainStations[(df_PassengerVolumeByTrainStations['DAY_TYPE'] == DAY_TYPE) & (df_PassengerVolumeByTrainStations['PT_TYPE'] == 'TRAIN') & (df_PassengerVolumeByTrainStations['mrt_station_english'] == mrt_station_english)]
    df_grouped = df_filtered.groupby('TIME_PER_HOUR')[Category].sum().reset_index()
    df_grouped_sorted = df_grouped.sort_values('TIME_PER_HOUR')
    
    plt.figure(figsize=(10, 6))
    plt.plot(df_grouped_sorted['TIME_PER_HOUR'], df_grouped_sorted[Category], marker='o', linestyle='-', color='b')
    plt.title(f'{Category} Over Time for {mrt_station_english} on {DAY_TYPE}')
    plt.xlabel('Time per Hour')
    plt.ylabel(f'{Category}')
    plt.grid(True)
    plt.xticks(np.arange(min(df_grouped_sorted['TIME_PER_HOUR']), max(df_grouped_sorted['TIME_PER_HOUR'])+1, 1.0))
    plt.tight_layout()
    plt.savefig('static\\temp_plot.png', dpi=300) 
    # plt.show()
    plot_present.append("static\temp_plot.png")
    return {
        "text": "Here is your plot:",
        "plotUrl": "static\temp_plot.png"
        }     

@tool
def passenger_volume_train(query:str)->str:
    """Useful for performing data analysis of the tap in and tap out volume of train stations."""
    file = 'Dataset/TrainStationCodes.xls'
    df_trainstationcodes = pd.read_excel(file)
    df_trainstationcodes
    #######
    df_PassengerVolumeByTrainStations = pd.read_csv('transport_node_train_202402.csv')
    ########
    print(df_PassengerVolumeByTrainStations)
    df_PassengerVolumeByTrainStations = pd.merge(df_PassengerVolumeByTrainStations, df_trainstationcodes[['stn_code', 'mrt_station_english']], left_on='PT_CODE', right_on='stn_code', how='left')
    print(df_PassengerVolumeByTrainStations)
    df_PassengerVolumeByTrainStations = df_PassengerVolumeByTrainStations.drop('stn_code', axis=1)

    df_PassengerVolumeByTrainStations = df_PassengerVolumeByTrainStations.dropna(subset=['mrt_station_english'])



    agent = create_pandas_dataframe_agent(OpenAI(temperature=0), 
              df_PassengerVolumeByTrainStations, verbose=True) 
    openai = OpenAI(temperature=0.0) 
    text = agent(query)
    return text

@tool
def passenger_volume_bus(query:str)->str:
    """Useful for performing data analysis of the tap in and tap out volume of bus"""
    df_PassengerVolumeByBusStops = pd.read_csv('transport_node_bus_202402.csv')
    agent = create_pandas_dataframe_agent(OpenAI(temperature=0), 
                df_PassengerVolumeByBusStops, verbose=True) 
    openai = OpenAI(temperature=0.0) 
    openai.model_name # This will print the model being used, 
                    # by default it uses ‘text-davinci-003’
    text = agent(query)
    return text


def LLM_init():
    os.environ["OPENWEATHERMAP_API_KEY"] = "4d4e54063f06f26b9e686dfb7fa29a33"
    os.environ["SERPER_API_KEY"] =  "e472b00872e8446ecbf94321d0f53ca351c9da85"
    os.environ["OPENAI_API_KEY"] = secrets['OPENAI_API_KEY']
    weather = OpenWeatherMapAPIWrapper()
    search = GoogleSerperAPIWrapper()
    llm = OpenAI(temperature=0.1)

    tools =[
         Tool(
            name = "followup",
            func = follow_up,
            description = "Ask follow-up question if the user's question is unclear"
        ),
        
        Tool(
            name="current search",
            func=search.run,
            description="useful for when you need to answer questions about current events or the current state of the world"
        ),
        Tool(
            name = "weather",
            func = weather.run,
            description = "Return current weather data based on location"
        ),
        Tool(
            name = "getlength",
            func = get_word_length,
            description = "Return the length of a word"
        ),
        
        Tool(
            name = "get_weather_news",
            func = get_weather_news,
            description = "Used when the user wants to know both the weather and current news. Give traveling/route suggestions according to the weather and traffic information you know"
        ),

        Tool(
            name="taxi_availability",
            func=taxi_availability,
            description="return the number of available taxis nearby when users ask if there are any taxis available at a location"
            ),
        
        Tool(
            name = 'get_carpark_availability',
            func = get_carpark_availability,
            description = "Return the names of the nearby carparks and the number of available lots in the nearby carparks when users ask what is the carpark availability of a location"
        ),

        Tool(
            name = "review_driving_chain",
            func = review_driving_chain,
            description = "MUST BE USED when the user wants to drive from a starting point to a destination. Generate a traffic report and analyze the nearby carparks availability and the traffic conditions for them to determine whether driving is an efficient, feasible and favorable option."
        ),

        Tool(
            name = "describe_traffic_cameras",
            func = describe_traffic_cameras,
            description = "Used when the user wants to know the description of traffic cameras along the way from the starting point to the destination"
        ),
        Tool(
            name = 'traffic map',
            func = traffic_map,
            description = 'To be used to generate a map image of route'
        ),
        Tool(
            name = 'traffic summary',
            func = traffic_summary,
            description = 'To be used to generate a concise summary of the current traffic incidents in Singapore for general road traffic manager'
        ),
        Tool(
            name = 'bus and train volume summary',
            func = volume_summary,
            description = 'To be used to get information of the passenger volume for bus or train for the past month'
        ),

        Tool(
            name = "get_train_alerts",
            func = get_train_alerts,
            description = "MUST BE USED when the users want to take a train or ask if there are any train disruptions now"
            ),

        Tool(
            name = "get_weather",
            func = get_weather,
            description = "use to suggest walking or cycling if the weather permits"
        ),
        Tool(
            name = 'bus volume plot',
            func = bus_volume_plot,
            description = "use to get the plot of passengers in each bus stop"
        ),
        Tool(
            name = 'train volume plot',
            func = train_volume_plot,
            description = "use to get the plot of passengers in each train/MRT stations"
        ),
        Tool(
            name = 'passenger volume bus',
            func = passenger_volume_bus,
            description = "Useful for getting information of the tap in and tap out of bus "
        ),
        Tool(
            name = 'passenger volume train',
            func = passenger_volume_train,
            description = "Useful for getting information of the tap in and tap out of train stations."
        )

    ]

    memory = ConversationBufferMemory(memory_key="chat_history",input_key="input", output_key="output",return_messages=True)
    
    new_instruction = """You are Routey, a route planning assistant and a large language model trained by OpenAI. You are here to help the Human find the most efficient and sustainable route in Singapore

    Routey is designed to be able to assist with a wide range of tasks related to travel and route suggesting, from offering simple route suggestion to providing in-depth explanations and discussions on weather and traffic conditions.
    As a language model, Routey is able to generate human-like text based on the input it receives, allowing it to engage in natural-sounding conversations and provide responses that are coherent and relevant to the topic at hand.
    Moreover, it is passionate about sustainability and keen on encouraging humans to use eco-friendly routes.  

    Routey is able to use existing traffic data sources and communication systems to enhance traffic flow, reduce congestion, promote greener mobility options and improve overall road safety in urban environments. And it is constantly learning and improving, and its capabilities are constantly evolving. It is able to process and understand large amounts of text, and can use this knowledge to provide accurate and informative responses to weather conditions, traffic flows conditions. 
    Additionally, Assistant is able to generate its own text based on the input it receives, allowing it to engage in discussions and provide explanations and descriptions on a wide range of topics.

    Overall, Routey is a powerful tool that can help with route planning and provide valuable insights and information on weather and traffic conditions.
    Whether you need help with planning for a route or just want to have a conversation about the weather and the traffic, Routey is here to assist.

    To answer the questions, you must get these three pieces of information: 1) the user's starting point; 2) the user's destination; 3) the user's preferred mode of transportation (e.g., bicycling, walking, taking public transport, driving, taxi)
    PLEASE ASK THE USERS IF YOU ARE MISSING ANY OF THE INFORMATION ABOVE.
    PLEASE ASK THE USERS IF YOU ARE MISSING ANY OF THE INFORMATION ABOVE.
    PLEASE ASK THE USERS IF YOU ARE MISSING ANY OF THE INFORMATION ABOVE.
    If you don't have all the information, always ask the user to provide more details for you. 
    
    Based on the user's input, answer the questions as best as you can. Use any tools when needed. If the query requires route map or weather information, please use the tools provided. The weather data provided is real-time data. 
    Only answer in the context of Singapore and always keep sustainability and eco-friendliness in your mind.

    If the user DO NOT want to use public transport like bus, train or to walk , suggest to take taxi. please use the tool to provide the number of available taxi in the location.

    If the user wants to take taxi, please use the tool to provide the number of available taxi in the location.

    If the user wants to take the for any train disruption or ask for train route, MUST use the tool to provide the health answer of the train. 
    
    Provide detailed routes and incidents along the route. 

    Only plot graphs if the user wants the plot.

    If you still don't know the answer after considering all the tools, ask the user to clairfy it for you instead of making up the answer.
    
    If user is a road traffic manager, ask if he/she would like a traffic summary or analyse the passenger volume for the past month.

    If user is a road traffic manager, provide summarized and concise answers for summary, do not treat traffic manager as a motorist.

    """
    
    llm_chain = initialize_agent(
        tools,
        agent=AgentType.CONVERSATIONAL_REACT_DESCRIPTION,
        llm = ChatOpenAI(temperature=0.2, model="gpt-4", openai_api_key=secrets['OPENAI_API_KEY']),
        # llm=llm, 
        memory=memory, 
        verbose=True,
        agent_kwargs = {'prefix':new_instruction}
    )
    
    return llm_chain                          
agent = LLM_init()


if __name__ == '__main__':
    app.run()
